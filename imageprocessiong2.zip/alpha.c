
/* Jatin : Hardcoding....
 *  Don't use if you don't know what I assumed..,.
 *  */

#include <stdio.h>

#define	TRANS	0.50

FILE *in1,*in2,*out;



int main(int argc, char **argv)
{
	unsigned char y1,r1,g1,b1;
	unsigned char y2,r2,g2,b2;
	int count; 

	in1 = fopen("1.bmp","rb");
	in2 = fopen("2.bmp","rb");
	out = fopen("out.bmp","wb");

	if((NULL == in1) || (NULL == in2) || (NULL == out))
		return -1;
	for(count = 0; count < 54; count ++)
	{
		fputc(fgetc(in1),out);
	}
    printf("Alphablending 1.bmp and 2.bmp into out.bmp\n");
	fseek(in1,54,SEEK_SET);
	fseek(in2,54,SEEK_SET);


	while(!feof(in1))
	{

		b1 = fgetc(in1);
		g1 = fgetc(in1);
		r1 = fgetc(in1);

		b2 = fgetc(in2);
		g2 = fgetc(in2);
		r2 = fgetc(in2);

		if(b1 + (TRANS * b2) < 254)
		b1+=(TRANS * b2);
		if(g1 + (TRANS * g2) < 254)
		g1 += (TRANS * g2);
		if(r1 + (TRANS * r2) < 254)
		r1 += (TRANS * r2);

		fputc(b1,out);
		fputc(g1,out);
		fputc(r1,out);

		
	}
    

	fclose(in1);
	fclose(in2);
	fclose(out);
	
	printf("Done with alpha blending 1.bmp and 2.bmp into out.bmp\nPlease check out your out.bmp ;-)\n");

	return 0;
}

