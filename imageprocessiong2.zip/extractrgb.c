/* Jatin : Hardcoding....
 *  Don't use if you don't know what I assumed..,.
 *  */

#include <stdio.h>

#define	TRANS	0.4

FILE *in1,*out1,*out2,*out3;


#define	FACTOR	15

int main(int argc, char **argv)
{
	unsigned char y1,r1,g1,b1;
	unsigned char y2,r2,g2,b2;
	int count; 

	in1 = fopen("1.bmp","rb");
	out1 = fopen("out1.bmp","wb");
	out2 = fopen("out2.bmp","wb");
	out3 = fopen("out3.bmp","wb");


	if((NULL == in1) || (NULL == out1) || (NULL == out2) || (NULL == out3))
		return -1;

	for(count = 0; count < 54; count ++)
	{
		fputc(fgetc(in1),out1);
	}

	fseek(in1,0,SEEK_SET);

	for(count = 0; count < 54; count ++)
	{
		fputc(fgetc(in1),out2);
	}

	fseek(in1,0,SEEK_SET);

	for(count = 0; count < 54; count ++)
	{
		fputc(fgetc(in1),out3);
	}

	fseek(in1,54,SEEK_SET);



	while(!feof(in1))
	{

		b1 = fgetc(in1);
		g1 = fgetc(in1);
		r1 = fgetc(in1);

		fputc(b1,out1);
		fputc(0,out1);
		fputc(0,out1);
			
		fputc(0,out2);
		fputc(g1,out2);
		fputc(0,out2);

		fputc(0,out3);
		fputc(0,out3);
		fputc(r1,out3);
		
		
	}
    

	fclose(in1);
	fclose(out1);
	fclose(out2);
	fclose(out3);
	
	printf("Hello World\n");

	return 0;
}

