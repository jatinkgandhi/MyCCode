
#include <stdio.h>

#define	TRANS	0.4

FILE *in1,*in2,*out;



int main(int argc, char **argv)
{
	unsigned char y1,r1,g1,b1;
	unsigned char y2,r2,g2,b2;
	int count; 

	in1 = fopen("1.bmp","rb");
	in2 = fopen("2.bmp","rb");
	out = fopen("out.bmp","wb");

	if((NULL == in1) || (NULL == in2) || (NULL == out))
		return -1;
	for(count = 0; count < 54; count ++)
	{
		fputc(fgetc(in1),out);
	}

	fseek(in1,54,SEEK_SET);
	fseek(in2,54,SEEK_SET);


	while(!feof(in1))
	{

		b1 = fgetc(in1);
		g1 = fgetc(in1);
		r1 = fgetc(in1);

		b2 = fgetc(in2);
		g2 = fgetc(in2);
		r2 = fgetc(in2);

		b1 |= b2;
		g1 |= g2;
		r1 |= r2;

		fputc(b1,out);
		fputc(g1,out);
		fputc(r1,out);

		
	}
    

	fclose(in1);
	fclose(in2);
	fclose(out);
	
	printf("Hello World\n");

	return 0;
}
